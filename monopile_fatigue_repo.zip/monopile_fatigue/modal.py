"""Modal properties of the four installation stages (wraps fem.py, Phase A model)."""
import numpy as np
import fem
from scipy.linalg import eigh

STAGES = ["Bare monopile", "+ Transition piece", "+ Tower", "+ Nacelle and rotor"]
D_WET = 30.0            # still-water level above mudline [m]


def section_props(zm):
    """outer diameter, wall thickness, section modulus Z and second moment I at height zm"""
    D, t = fem.section(zm, None)
    Di = D - 2 * t
    I = np.pi / 64 * (D**4 - Di**4)
    return dict(D=D, t=t, I=I, Z=I / (D / 2))


def modal_props(stage, nh=fem.NH["medium"], dz=1.0):
    """Mode 1 of a stage: f1, shape, generalised mass/stiffness (phi_max = 1 at the top).
    The eigenvector is computed here, not taken from fem.modes(): fem.modes() normalises the translations
    through a view of the eigenvector but leaves the rotations unscaled (see README, 'Note on fem.py')."""
    z, K, M, free = fem.build(stage, nh=nh, dz=dz)
    w2, V = eigh(K, M, subset_by_index=[0, 2])
    v = V[:, 0] / V[0::2, 0][np.argmax(abs(V[0::2, 0]))]          # full vector, translation max = 1
    f1 = np.sqrt(w2[0]) / 2 / np.pi
    sel = (z >= 0) & (z <= D_WET + 1e-9)
    Mn = v @ M @ v
    return dict(stage=stage, z=z, f=np.sqrt(w2) / 2 / np.pi, f1=f1, phi=v[0::2], phi_w=v[0::2][sel],
                Mn=Mn, Kn=(2 * np.pi * f1) ** 2 * Mn, Vn=v, nh=nh)


def moment_per_q(mp, z_target):
    """Internal bending moment at height z_target per unit modal amplitude (phi_top = 1) [N m],
    taken from the element just above z_target. Sign: positive for a forward-deflected pile."""
    z, Vn = mp["z"], mp["Vn"]
    i = int(np.argmin(abs(z - z_target)))
    L = z[i + 1] - z[i]
    sp = section_props(0.5 * (z[i] + z[i + 1]))
    u = Vn[2 * i:2 * i + 4]
    curv = (-6 * u[0] - 4 * L * u[1] + 6 * u[2] - 2 * L * u[3]) / L**2
    return abs(fem.E * sp["I"] * curv), sp


def tower_effective_mass(mp):
    """mass per metre weighted by phi^2 over the tower (steel only) [kg/m], and top diameter"""
    z, phi = mp["z"], mp["phi"]
    sel = (z >= fem.Z_TP_TOP) & (z < fem.Z_HUB)
    m = np.array([fem.RHO_S * np.pi / 4 * (lambda D, t: D**2 - (D - 2 * t)**2)(*fem.section(zz + 0.01, None)) for zz in z[sel]])
    return float(np.sum(m * phi[sel]**2) / np.sum(phi[sel]**2))
