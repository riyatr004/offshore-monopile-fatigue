"""Verification checks. Run:  python checks.py   (needs results_B.json from phase_b_loading.py and results_C_*.csv from phase_c_fatigue.py)"""
import json, numpy as np, pandas as pd
from scipy.optimize import brentq
import loads, fatigue as fat, modal, fem

ok = lambda c: "PASS" if c else "FAIL"
res = []

# 1 wave number solver
w = 2 * np.pi * np.array([.05, .1, .3, 1., 1.8]); kb = [brentq(lambda k: o**2 - 9.81 * k * np.tanh(k * 30), 1e-6, 20) for o in w]
res.append(("wave number: Newton vs brentq", np.max(abs(loads.wavenumber(w) - kb)) < 1e-9))

# 2 regression against the Phase B report numbers (Phase B grid)
B = json.load(open("results_B.json"))["cases"]; f = np.linspace(.02, 1.8, 3560); grid = loads.WaveGrid(f); worst = 0
for n, r in B.items():
    S, F, _ = grid.tf(r["Hs"], r["Tp"]); M = grid.moment_tf(F); sig = np.sqrt(np.sum(abs(M)**2 * S) * grid.df)
    worst = max(worst, abs(sig / 1e6 / r["Mrms_MNm"] - 1))
res.append(("mudline moment RMS equals Phase B (all six sea states), worst deviation %.2e" % worst, worst < 1e-3))

# 3 rainflow against an independent implementation
x = np.cumsum(np.random.default_rng(1).normal(size=3000)); r, c = fat.rainflow(x)
try:
    import rainflow as rf
    ref = sorted((round(a, 6), cc) for a, cc in rf.count_cycles(x)); mine = {}
    for a, cc in zip(r, c): mine[round(a, 6)] = mine.get(round(a, 6), 0) + cc
    ref_d = {}
    for a, cc in ref: ref_d[a] = ref_d.get(a, 0) + cc
    res.append(("rainflow: same cycle ranges and counts as the 'rainflow' package", mine.keys() == ref_d.keys() and all(abs(mine[k] - ref_d[k]) < 1e-9 for k in mine)))
except ImportError:
    res.append(("rainflow package not installed: ASTM example only", len(r) == 7 and abs(c.sum() - 4.0) < 1e-9))

# 4 time-domain std vs spectral sigma, and damage agreement (Phase C output)
LC = pd.read_csv("results_C_LC.csv"); res.append(("time-domain stress std equals spectral sigma (max dev %.1f %%)" % (100 * np.max(abs(LC.sig_td / LC.sig_MPa - 1))), np.max(abs(LC.sig_td / LC.sig_MPa - 1)) < .03))
sc = pd.read_csv("results_C_scatter.csv"); b = fat.BASE; tot = lambda m: sc.groupby("stage")[m + "|" + b].apply(lambda s: np.sum(s * sc.loc[s.index, "hours"] / 3))
td, dk = tot("td"), tot("dirlik"); dev = np.max(abs(td / dk - 1))
res.append(("6-month damage: rainflow vs Dirlik, max deviation %.1f %%" % (100 * dev), dev < .10))

# 5 hand checks
mp = modal.modal_props(0); m0, sp = modal.moment_per_q(mp, 0.)
sig_hand = B["LC5"]["Mrms_MNm"] * 1e6 / sp["Z"] / 1e6
sig_num = LC[(LC.Hs == 4) & (LC.Tp == 8) & (LC.stage == "Bare monopile")].sig_MPa.iloc[0]
res.append(("LC5 bare pile: M_rms / Z = %.2f MPa vs numerical %.2f MPa (dynamic part +%.0f %%)" % (sig_hand, sig_num, 100 * (sig_num / sig_hand - 1)), abs(sig_num / sig_hand - 1) < .05))
res.append(("critical wind speed tower: f1 D / St = %.1f m/s (Phase B: 11.5)" % (modal.modal_props(2)["f1"] * 4.5 / .2), abs(modal.modal_props(2)["f1"] * 4.5 / .2 - 11.5) < .1))
fn = np.array([modal.modal_props(s)["f1"] for s in range(4)]); res.append(("first frequencies equal Phase A/B (1.22 / 0.86 / 0.51 / 0.26 Hz)", np.allclose(fn, [1.22, .86, .51, .26], atol=.01)))

for name, c in res: print("[%s] %s" % (ok(c), name))
raise SystemExit(0 if all(c for _, c in res) else 1)
