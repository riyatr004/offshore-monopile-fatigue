"""Complex wave-load transfer functions on an arbitrary frequency grid.
Same physics as phase_b_loading.py (JONSWAP, Airy waves, linearised Morison with Borgman drag and
MacCamy-Fuchs inertia correction) but returns complex transfer functions (inertia 90 deg out of phase
with drag) so that time series can be simulated.  Regression-tested against results_B.json (checks.py)."""
import numpy as np
from scipy.special import jvp, yvp

g, RHO_W, D_P, d = 9.81, 1025.0, 8.0, 30.0
CM, CD = 2.0, 1.0
AP = np.pi * D_P**2 / 4


def wavenumber(om):
    """Vectorised Newton solution of om^2 = g k tanh(k d)."""
    k = om**2 / g / np.sqrt(np.tanh(om**2 * d / g))
    for _ in range(60):
        t = np.tanh(k * d)
        k = k - (g * k * t - om**2) / (g * t + g * k * d * (1 - t**2))
    return k


def jonswap(f, Hs, Tp):
    fp = 1 / Tp
    x = Tp / np.sqrt(Hs)
    gam = 5.0 if x <= 3.6 else 1.0 if x >= 5 else np.exp(5.75 - 1.15 * x)
    sig = np.where(f <= fp, 0.07, 0.09)
    S = f**-5 * np.exp(-1.25 * (fp / f)**4) * gam**np.exp(-0.5 * ((f / fp - 1) / sig)**2)
    S *= Hs**2 / 16 / np.sum(S * (f[1] - f[0]))
    return S, gam


class WaveGrid:
    def __init__(self, f, dz=1.0, mf=True):
        self.f, self.df = f, f[1] - f[0]
        self.w = 2 * np.pi * f
        self.k = wavenumber(self.w)
        self.zb = np.arange(0, d + 1e-9, dz)
        kin = np.cosh(np.outer(self.zb, self.k)) / np.sinh(self.k * d)
        self.Uu, self.Aa = self.w * kin, self.w**2 * kin
        x = self.k * D_P / 2
        self.cm_ratio = (4 / (np.pi * x**2) / np.sqrt(jvp(1, x)**2 + yvp(1, x)**2)) / 2 if mf else np.ones_like(f)

    def tf(self, Hs, Tp):
        """sea-state spectrum S(f) [m^2/Hz] and complex force TF F(z,f) [N/m per m of wave amplitude]"""
        S, gam = jonswap(self.f, Hs, Tp)
        su = np.sqrt(np.sum(self.Uu**2 * S * self.df, axis=1))
        cd = 0.5 * RHO_W * CD * D_P * np.sqrt(8 / np.pi) * su          # Borgman
        Fi = RHO_W * CM * AP * self.Aa * self.cm_ratio
        F = 1j * Fi + cd[:, None] * self.Uu                              # inertia (i) + drag (real)
        return S, F, gam

    def moment_tf(self, F):                                              # mudline overturning moment
        return np.trapezoid(self.zb[:, None] * F, self.zb, axis=0)

    def modal_tf(self, F, phi_w):                                        # modal force
        return np.trapezoid(phi_w[:, None] * F, self.zb, axis=0)


def sdof_H(f, f1, zeta):
    """displacement per static displacement"""
    return 1 / (1 - (f / f1)**2 + 2j * zeta * f / f1)


def stress_tf(grid, F, mp, zeta, m_mud, Z_sec, scf=1.0):
    """Bending-stress TF at the mudline weld [MPa per m wave amplitude].
    Exact quasi-static moment from the wave force + dynamic correction of mode 1 (mode-acceleration form):
    M = M_direct + m_mud * (H - 1) * Q / K_n"""
    Mdir = grid.moment_tf(F)
    Q = grid.modal_tf(F, mp["phi_w"])
    H = sdof_H(grid.f, mp["f1"], zeta)
    return scf * (Mdir + m_mud * (H - 1) * Q / mp["Kn"]) / Z_sec / 1e6


def top_motion_tf(grid, F, mp, zeta):
    """modal displacement of the top (phi_top = 1) [m per m wave amplitude]"""
    return sdof_H(grid.f, mp["f1"], zeta) * grid.modal_tf(F, mp["phi_w"]) / mp["Kn"]


def realise(f, S, H, T, dt, rng):
    """Time series of a linear response with complex TF H to sea state S; grid must be f_k = k/T."""
    N = int(round(T / dt)); k = np.rint(f * T).astype(int)
    a = np.sqrt(2 * S * (f[1] - f[0])) * np.abs(H)
    X = np.zeros(N // 2 + 1, complex)
    X[k] = a * N / 2 * np.exp(1j * (rng.uniform(0, 2 * np.pi, len(f)) + np.angle(H)))
    return np.fft.irfft(X, n=N)
