"""S-N curves, rainflow counting, Miner damage, spectral damage (narrow band and Dirlik).
S-N parameters: DNV-RP-C203 curve D (stress in MPa).  VERIFY against the current edition before reporting."""
import numpy as np
from dataclasses import dataclass


@dataclass
class SN:
    name: str
    a1: float; m1: float
    a2: float = None; m2: float = None     # second branch (None = single slope)
    N_knee: float = None
    k: float = 0.20                        # thickness exponent
    t_ref: float = 25.0                    # mm

    def thick(self, t_mm):
        return max(t_mm / self.t_ref, 1.0) ** self.k

    def inv_N(self, S):
        """damage per cycle 1/N(S) for effective stress range S [MPa]"""
        S = np.asarray(S, float)
        out = S**self.m1 / self.a1
        if self.a2 is not None:
            S_knee = (self.a1 / self.N_knee) ** (1 / self.m1)
            out = np.where(S > S_knee, out, S**self.m2 / self.a2)
        return out


CURVES = {
    "seawater, cathodic protection": SN("D seawater CP", 10**11.764, 3, 10**15.606, 5, 1e6),
    "in air": SN("D in air", 10**12.164, 3, 10**15.606, 5, 1e7),
    "free corrosion": SN("D free corrosion", 10**11.687, 3),
}
BASE = "seawater, cathodic protection"


# ---------------- rainflow (ASTM E1049 three-point) ----------------
def turning_points(x):
    x = np.asarray(x); d = np.diff(x)
    keep = np.r_[True, d[1:] * d[:-1] < 0, True]
    keep &= np.r_[True, d != 0]  # drop repeated values
    return x[keep]


def rainflow(x):
    """returns (ranges, counts); counts are 1 for full and 0.5 for half cycles"""
    stack, rng_, cnt = [], [], []
    for p in turning_points(x):
        stack.append(p)
        while len(stack) >= 3:
            X = abs(stack[-1] - stack[-2]); Y = abs(stack[-2] - stack[-3])
            if X < Y: break
            if len(stack) == 3:
                rng_.append(Y); cnt.append(0.5); stack.pop(0)
            else:
                last = stack.pop(); stack.pop(); stack.pop(); stack.append(last)
                rng_.append(Y); cnt.append(1.0)
    for i in range(len(stack) - 1):
        rng_.append(abs(stack[i + 1] - stack[i])); cnt.append(0.5)
    return np.array(rng_), np.array(cnt)


def damage_ranges(ranges, counts, sn, t_mm):
    """Miner sum for rainflow ranges [MPa] (nominal stress already includes SCF)"""
    return float(np.sum(counts * sn.inv_N(ranges * sn.thick(t_mm))))


# ---------------- spectral fatigue ----------------
def spectral_moments(f, G):
    df = f[1] - f[0]
    return [np.sum(f**n * G * df, axis=-1) for n in (0, 1, 2, 4)]


def _zgrid():
    return np.linspace(1e-4, 14, 3000)


def dirlik_damage(f, G, sn, t_mm, T, scale=1.0, method="dirlik"):
    """Expected damage in time T [s] for stress spectrum G(f) [MPa^2/Hz] (one-sided, nominal).
    G may be 2-D [n, nf]; scale multiplies the stress (e.g. Hs factor). method: 'dirlik' or 'narrow'."""
    G = np.atleast_2d(G)
    m0, m1, m2, m4 = spectral_moments(f, G)
    Z = _zgrid(); dZ = Z[1] - Z[0]
    s = 2 * np.sqrt(m0) * scale * sn.thick(t_mm)                    # S_eff = s * Z
    invN = sn.inv_N(s[:, None] * Z[None, :])
    if method == "narrow":
        pZ = Z * np.exp(-Z**2 / 2)[None, :] * np.ones((len(m0), 1))
        rate = np.sqrt(m2 / m0)
    else:
        gam = m2 / np.sqrt(m0 * m4); xm = m1 / m0 * np.sqrt(m2 / m4)
        D1 = 2 * (xm - gam**2) / (1 + gam**2)
        R = (gam - xm - D1**2) / (1 - gam - D1 + D1**2)
        D2 = (1 - gam - D1 + D1**2) / (1 - R); D3 = 1 - D1 - D2
        Q = 1.25 * (gam - D3 - D2 * R) / D1
        c = lambda a: a[:, None]
        pZ = (c(D1 / Q) * np.exp(-Z[None, :] / c(Q)) + c(D2 / R**2) * Z[None, :] * np.exp(-Z[None, :]**2 / (2 * c(R)**2))
              + c(D3) * Z[None, :] * np.exp(-Z[None, :]**2 / 2))
        rate = np.sqrt(m4 / m2)
    return rate * T * np.sum(pZ * invN, axis=1) * dZ     # T may be a scalar or one value per spectrum
