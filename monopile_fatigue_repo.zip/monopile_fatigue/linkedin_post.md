Before a wind turbine is connected, its foundation can stand bare in the North Sea for months, with nobody measuring it. How much fatigue damage does it pick up?

I built a Python model to find out: beam-on-springs for four installation stages, JONSWAP waves with linearised Morison loads (diffraction-corrected for an 8 m pile), rainflow counting, DNV D-curve, Miner's rule, and a Monte Carlo study on soil, damping and wave height.

What came out (illustrative data):

- Waves alone do very little damage to the bare monopile: about 0.0003 over six months, 0.003 at the 95th percentile.
- Storms above 4.5 m Hs are 4% of the time but cause almost half of it.
- The stage to watch is the tower without rotor. Its critical wind speed sits in the normal wind range, so vortex shedding can lock in for roughly 30% of the time. Whether that matters depends on an amplitude nobody has measured.
- So the logger should resolve tiny accelerations (about 30 ug/sqrt(Hz)) and catch storms and lock-in events, not log everything.

Limits: linear soil, one mode, assumed VIV amplitude. S-N constants need checking against the standard.

Code and a 4-page summary: [repository link]

#OffshoreWind #StructuralDynamics #FatigueAnalysis #Python
