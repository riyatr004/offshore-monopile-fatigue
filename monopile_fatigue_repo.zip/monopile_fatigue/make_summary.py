"""Builds technical_summary.pdf from the result files (so the numbers cannot drift from the code)."""
import json, numpy as np, pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, KeepTogether
import fatigue as fat, modal

b = fat.BASE
C = json.load(open("results_C.json")); D = json.load(open("results_D.json")); mc = D["mc"]; spec = D["spec"]
sc = pd.read_csv("results_C_scatter.csv"); lc = pd.read_csv("results_C_LC.csv"); lg = pd.read_csv("logger_signal_levels.csv"); st = pd.read_csv("logger_strategies.csv")
S = modal.STAGES; tot = C["totals_6m"]; V = C["viv"]
e = lambda x: ("%.1e" % x).replace("e-0", "e-").replace("e+0", "e+")
sig5 = {s: lc[(lc.case == "LC5") & (lc.stage == s)].sig_MPa.iloc[0] for s in S}
f1 = {s: [modal.modal_props(i, nh=n)["f1"] for n in (5e6, 15e6, 40e6)] for i, s in enumerate(S)}
d0 = sc[sc.stage == S[0]].copy(); d0["D6"] = d0["dirlik|" + b] * d0.hours / 3
storm_share = d0[d0.Hs > 4.5].D6.sum() / d0.D6.sum(); storm_time = d0[d0.Hs > 4.5].hours.sum() / 4380

ss = getSampleStyleSheet()
N = ParagraphStyle("n", parent=ss["Normal"], fontName="Helvetica", fontSize=8.6, leading=11.2, spaceAfter=4)
H1 = ParagraphStyle("h1", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=11.5, spaceBefore=7, spaceAfter=3, textColor=colors.HexColor("#1f3b5c"))
T = ParagraphStyle("t", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=15, leading=18, spaceAfter=2)
CAP = ParagraphStyle("c", parent=N, fontSize=7.4, leading=9, textColor=colors.HexColor("#444444"), spaceAfter=6)
SM = ParagraphStyle("s", parent=N, fontSize=7.4, leading=9, spaceAfter=0)
BOX = ParagraphStyle("b", parent=N, backColor=colors.HexColor("#eaf1f8"), borderPadding=(5, 6, 5, 6), spaceBefore=4, spaceAfter=8)
P = lambda t, s=N: Paragraph(t, s)
img = lambda f, w=17.2: Image(f, width=w * cm, height=w * cm * (lambda im: im.getSize()[1] / im.getSize()[0])(__import__("reportlab.lib.utils", fromlist=["ImageReader"]).ImageReader(f)))


def table(rows, widths, head=True, fs=7.4):
    t = Table([[Paragraph(str(c), ParagraphStyle("x", parent=SM, fontSize=fs, leading=fs + 1.6, fontName="Helvetica-Bold" if (head and i == 0) else "Helvetica")) for c in r] for i, r in enumerate(rows)], colWidths=[w * cm for w in widths], repeatRows=1)
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), .3, colors.HexColor("#999999")), ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dde7f2")),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2)]))
    return t


def footer(c, d):
    c.saveState(); c.setFont("Helvetica", 7); c.setFillColor(colors.grey)
    c.drawString(1.8 * cm, 1.0 * cm, "Portfolio project | Riya Thripakkal Rajesh | M.Sc. ACCESS, TU Dresden | Illustrative study, not for design use"); c.drawRightString(A4[0] - 1.8 * cm, 1.0 * cm, "Page %d" % d.page); c.restoreState()


w, vt, vr = mc[S[0]]["wave"][b], mc[S[2]]["wave_plus_viv"], mc[S[3]]["wave"][b]
Alim = {s: np.interp(1 / C["DFF"], np.array(V[s]["damage"][b]), np.array(V[s]["A_over_D"])) * 4.5 for s in (S[2], S[3])}
story = [P("Fatigue Risk of Bare Offshore Monopiles During Installation: A Python-Based Study", T),
         P("Technical summary | Riya Thripakkal Rajesh | M.Sc. ACCESS, TU Dresden | self-study portfolio project (not for design use)", CAP),
         P("<b>Question.</b> A monopile can stand bare for months before the turbine is connected. How much vibration and fatigue damage can it accumulate in a "
           "6-month waiting period, and what should a battery-powered logger record to capture it?", N),
         P("<b>Answer in short.</b> (1) Waves alone do almost no fatigue damage to the bare monopile: 6-month Miner damage at the mudline weld is <b>%s</b> "
           "(Monte Carlo P5 to P95: %s to %s), against an allowable of about %.2f (design fatigue factor %g). (2) The damage is dominated by rare storms: "
           "sea states above Hs = 4.5 m are %.0f %% of the time but cause %.0f %% of the damage. (3) The suspicious stage is the tower without rotor: "
           "its critical wind speed (11.5 m/s) is in the normal wind range, so it sits in the vortex lock-in band for %.0f h of the 6 months. Whether that matters depends on "
           "the lock-in amplitude, which this study cannot predict: the mudline weld reaches D = 1/DFF only if the tower top oscillates with about %.2f m amplitude "
           "(A/D = %.2f); a code-style screening estimate gives %.2f m. (4) The logger therefore should be built to resolve very small accelerations (about 0.4 mg RMS in a quiet sea) "
           "and to catch storms and lock-in events, not to log everything." % (e(tot[S[0]]["dirlik|" + b]), e(w["P5"]), e(w["P95"]), 1 / C["DFF"], C["DFF"],
                                                                         storm_time * 100, storm_share * 100, V[S[2]]["hours_in_band"], Alim[S[2]], Alim[S[2]] / 4.5, V[S[2]]["A_screen_m"]), BOX),
         P("1. Model and assumptions", H1),
         P("<b>Structure.</b> Euler-Bernoulli beam finite-element model (1 m elements) of a reference monopile: D = 8.0 m, t = 90 mm, 30 m embedded, 30 m water depth, "
           "transition piece at 40 m, tapered tower (D 6.5 to 4.5 m) to a 140 m hub, 200 t platform and 450 t nacelle-and-rotor mass; added water mass on the wet length. "
           "Soil is a Winkler foundation with linearly increasing stiffness n<sub>h</sub> (5 / 15 / 40 MN/m<super>3</super> for soft / medium / stiff). Four stages are analysed; "
           "first frequencies (medium soil) 1.22 / 0.86 / 0.51 / 0.26 Hz (soft to stiff: see table 1).", N),
         P("<b>Loading.</b> JONSWAP sea states (peak factor from the DNV rule), linear Airy waves, linearised Morison force (Cm = 2.0, Cd = 1.0, Borgman drag linearisation) with the "
           "MacCamy-Fuchs diffraction correction of the inertia term, because D/L reaches 0.14 to 0.34. The 8 m pile makes inertia dominate (drag below 0.5 %% of the moment variance). "
           "The 6-month sea-state table is synthetic: Weibull Hs (scale 1.9 m, shape 1.35, mean Hs %.1f m), lognormal Tp given Hs, steepness cut-off 1/15, %d states." % (np.sum(sc[sc.stage == S[0]].Hs * sc[sc.stage == S[0]].p), len(sc[sc.stage == S[0]])), N),
         P("<b>Response and stress.</b> Mudline overturning moment from the wave force (exact, quasi-static) plus a mode-1 dynamic correction (mode-acceleration form), "
           "damping 1 % of critical. Nominal bending stress at the mudline girth weld (Z = 4.37 m<super>3</super>, SCF = 1). Time series are simulated from the spectrum (3 h, random phases) and counted by "
           "rainflow; damage uses the DNV-RP-C203 D-curve with thickness correction (t/25 mm)<super>0.2</super> and Miner's rule. Spectral damage (Dirlik and narrow-band) is the cross-check.", N),
         img("fig_modes.png"), P("Figure 1. Mode shapes 1 to 3 for the four installation stages (medium soil). Only the three bare stages are free of the heavy rotor mass; the rotor stage has its first mode at 0.26 Hz, just above the wave band.", CAP)]

rows = [["Stage", "f<sub>1</sub> soft / med / stiff [Hz]", "Mudline stress RMS, LC5 [MPa]", "6-month damage, waves (Dirlik)", "Monte Carlo waves P5 / P50 / P95", "Time in VIV band [h]"]]
for s in S:
    m = mc[s]["wave"][b]
    ex = {S[2]: "%.0f" % V[S[2]]["hours_in_band"], S[3]: "%.0f" % V[S[3]]["hours_in_band"]}.get(s, "< 1 (Phase B)")
    rows.append([s, " / ".join("%.2f" % x for x in f1[s]), "%.1f" % sig5[s], e(tot[s]["dirlik|" + b]), "%s / %s / %s" % (e(m["P5"]), e(m["P50"]), e(m["P95"])), ex])
story += [P("2. Results", H1), P("<b>Table 1.</b> Stage comparison (baseline S-N curve: D, seawater with cathodic protection). Allowable damage is 1/DFF = %.2f. The rotor stage is shown for completeness: its wave response is qualitative only (no aerodynamic damping, JONSWAP tail)." % (1 / C["DFF"]), SM), Spacer(1, 3),
          table(rows, [3.0, 3.0, 2.9, 2.8, 3.5, 2.0]), Spacer(1, 5),
          P("<b>Waves.</b> The three bare stages respond almost quasi-statically (dynamic amplification 1.01 to 1.2, Phase B), so the mudline stress follows the wave moment: LC5 (Hs 4 m, Tp 8 s) gives 4.5 MPa RMS and about 18 MPa maximum in 3 h, "
            "consistent with the hand estimate M<sub>rms</sub>/Z = 4.4 MPa. At such low stress ranges nearly every cycle lies below the knee of the S-N curve, so the result is controlled by the shallow-slope branch and by "
            "the choice of curve: in air and in seawater with cathodic protection give identical damage (%s); free corrosion gives %s (about 16 times higher), which is still only %.0f %% of the allowable. "
            "Rainflow counting, Dirlik and the narrow-band formula agree within %.0f %% for all stages." % (e(tot[S[0]]["dirlik|in air"]), e(tot[S[0]]["dirlik|free corrosion"]),
                                                                                                          100 * tot[S[0]]["dirlik|free corrosion"] * 3, 100 * max(abs(tot[s]["td|" + b] / tot[s]["dirlik|" + b] - 1) for s in S)), N),
          img("fig_response.png"), P("Figure 2. Response spectrum of the mudline bending stress for LC5 (left) and a simulated 5-minute stress history (right). The bare pile follows the wave band; the tower and the rotor stage show their own resonances.", CAP),
          img("fig_damage.png"), P("Figure 3. Damage per day for each sea state (left) and the share of the 6-month damage by Hs bin for the bare monopile (right, with the share of time). Storms drive the damage; calm seas contribute almost nothing.", CAP)]

story += [P("3. Vortex-induced vibration: a scenario, not a prediction", H1),
          P("Phase B showed that the bare pile and the pile with transition piece have critical wind speeds of 36 m/s and above, so VIV is not a concern there. The tower without rotor (f<sub>1</sub> = 0.51 Hz, "
            "U<sub>c</sub> = %.1f m/s) is inside a +/-20 %% lock-in band for about %.0f h; with the rotor mounted but not operating, %.0f h. Exposure is not damage. "
            "A linear model cannot predict the lock-in amplitude, so the scenario is built the other way round: the stress range at the mudline is 2 A m/Z (m = %.0f MNm of mudline moment per metre of top amplitude), "
            "cycles are counted at f<sub>1</sub> over the time in the band with a triangular amplitude shape, and damage is plotted against the assumed amplitude (Figure 4). The reference point is an EN 1991-1-4 Annex E style estimate "
            "(Scruton number %.0f, A = %.2f m); its constants must be verified against the standard. At the mudline the damage at that amplitude is %s; the tower-base weld at 55 m is about 3 times lower in this mode "
            "(%s). The amplitude that would use up the allowable damage (D = 1/DFF) is %.2f m for the tower stage and %.2f m for the rotor stage." % (
                V[S[2]]["Uc"], V[S[2]]["hours_in_band"], V[S[3]]["hours_in_band"], V[S[2]]["m_mud_MNm_per_m"], V[S[2]]["Sc"], V[S[2]]["A_screen_m"],
                e(V[S[2]]["D_screen"][b]), e(V[S[2]]["tower_base"]["D_screen"]), Alim[S[2]], Alim[S[3]]), N),
          img("fig_viv.png"), P("Figure 4. Left: 6-month damage at the mudline weld against the assumed lock-in amplitude. Right: waves versus the VIV screening scenario by stage. Log scales.", CAP),
          P("4. Uncertainty (Monte Carlo)", H1),
          P("%d samples of: soil stiffness (lognormal, median 15 MN/m<super>3</super>, 5th to 95th percentile 5.6 to 40), damping (median 1.5 %%, 0.4 to 4 %%), a wave-severity factor on the whole scatter table (lognormal, sigma 0.25), and for VIV an amplitude model factor "
            "(lognormal, sigma 0.5) and the fraction of band time with developed lock-in (uniform 0.25 to 1). Input distributions are judgement, not data. Bare monopile: median %s, P95 %s, P99 %s, so even the 99th percentile is %.0f %% of the allowable. "
            "Tower stage with waves and the VIV scenario: median %s, P95 %s, P99 %s, probability of exceeding 1/DFF %.1f %%. The spread is driven by wave severity (rank correlation %.2f) before the VIV amplitude factor (%.2f) and damping (%.2f); "
            "soil stiffness hardly matters for the bare stages. The parked rotor stage reaches P95 = %s because its resonance sits on the spectrum tail; treat that number as a warning that aerodynamic damping and the tail shape must be modelled before any conclusion." % (
                D["n"], e(w["P50"]), e(w["P95"]), e(w["P99"]), 100 * w["P99"] * C["DFF"], e(vt["P50"]), e(vt["P95"]), e(vt["P99"]), 100 * vt["P_exceed_1_over_DFF"],
                mc["spearman_tower_wave_viv"]["wave height factor"], mc["spearman_tower_wave_viv"]["VIV amplitude factor"], mc["spearman_tower_wave_viv"]["damping"], e(vr["P95"])), N),
          img("fig_mc.png"), P("Figure 5. Distribution of the 6-month damage (log scale) for the bare monopile (waves) and the tower stage (waves plus VIV scenario), and rank correlations of the inputs with the tower-stage damage.", CAP)]

lr = lg.set_index("stage")
rq = [["Requirement", "Value", "Why (from the results)"],
      ["Measured quantity", "2 horizontal accelerations at the highest accessible point; inclination and temperature as slow channels; one strain or mudline channel if access allows",
       "Mode-1 motion is largest at the top; frequencies, damping and lock-in show up in acceleration"],
      ["Range", "+/- %.0f g (selectable)" % spec["range_g"], "Wave 3-h peak %.0f mg (tower stage); lock-in at D = 1/DFF: %.0f mg; parked rotor stage %.0f mg" % (lr.loc[S[2], "a_peak_wave_mg"], lr.loc[S[2], "a_viv_Dlimit_mg"], lr.loc[S[3], "a_peak_wave_mg"])],
      ["Noise floor", "at most %.0f ug/sqrt(Hz) in 0.03 to 2 Hz" % spec["noise_density_ug_rtHz"], "Smallest sea state that still matters (Hs about %.1f m, 99 %% of damage) gives only %.1f mg RMS on the bare pile; noise set to 10 %% of it" % (lr.loc[S[0], "Hs_min_99pct_damage"], lr.loc[S[0], "a_rms_min_relevant_mg"])],
      ["Frequency band", "0.03 to %.0f Hz" % spec["band_high_Hz"], "Wave band 0.08 to 0.17 Hz; bare-pile mode 1 at 0.8 to 1.5 Hz; mode 2 at 7.6 Hz (8.8 Hz stiff soil)"],
      ["Sampling rate", "%.0f Hz raw bursts, 10 Hz for the always-on channel" % spec["fs_raw_Hz"], "2.5 times the bare-pile mode 2 (stiff soil); the stress-relevant content is below 2 Hz"],
      ["Stored quantities", "10-min mean, RMS, max, min, dominant frequency and a 32-band spectrum; hourly rainflow range histogram (32 bins); raw bursts on triggers", "Statistics keep spectra and exposure, the histogram keeps damage, bursts keep waveforms"]]
sr = [["Strategy (6 months)", "Memory [MB]", "Mean power [mW]", "Energy [Wh]", "Keeps / loses"]]
for _, r in st.iterrows(): sr.append([r.strategy, "%.0f" % r.memory_MB if r.memory_MB > 20 else "%.1f" % r.memory_MB, "%.1f" % r.avg_power_mW, "%.0f" % r.energy_Wh, "%s / %s" % (r.keeps, r.loses)])
story += [P("5. Logger recommendation", H1), P("<b>Table 2.</b> Requirements derived from the response results (signal levels from mode 1 only, so a lower bound for high-frequency content).", SM), Spacer(1, 3), table(rq, [2.6, 6.2, 8.4]), Spacer(1, 6),
          P("<b>Table 3.</b> Logging strategies. Device values are assumptions (sensor 3 mW, microcontroller 30 mW active and 0.03 mW asleep, 1 uJ per stored byte, 24-bit, 2 channels); check them against data sheets. "
            "Memory differs by three orders of magnitude, but energy hardly differs, because the always-on sensor dominates the budget.", SM), Spacer(1, 3), table(sr, [4.6, 1.7, 1.8, 1.5, 7.6], fs=7),
          Spacer(1, 5),
          P("<b>Recommendation.</b> Run a hybrid: always-on 10-minute statistics with a spectrum, an on-board hourly rainflow histogram once the moment-to-acceleration transfer function has been calibrated against the model, and event-triggered raw bursts at %.0f Hz when the 10-minute RMS or the wind speed enters "
            "a lock-in band or a storm. This keeps the damage record, the spectrum and the waveforms where they matter at a few hundred MB instead of %.1f GB, and one primary lithium cell is enough for 6 months in this model. The first thing to measure is the lock-in amplitude of the tower stage, because it is the one unknown that this study cannot close." % (
                spec["fs_raw_Hz"], st.memory_MB[0] / 1000), N),
          img("fig_logger.png", 11.0), P("Figure 6. Top-acceleration spectra of the bare pile and the tower stage against the required sensor noise floor and the wave band.", CAP),
          P("6. Limitations and verification", H1),
          P("<b>Limitations.</b> Linear soil without cyclic degradation; one mode only (higher modes matter for the rotor stage); 1 % constant damping and no aerodynamic damping; Airy waves with no stretching, breaking, slamming, current or marine growth; "
            "generic synthetic sea states and Weibull wind, not site data; Strouhal number 0.2 and a +/-20 % band although the Reynolds number is about 3x10<super>6</super>, where shedding is less coherent and the tapered tower locks in only partly; "
            "VIV amplitude is an assumption; nominal stress with SCF = 1 at one cross-section (the maximum moment is below the seabed, and flanges and attachments are not checked); DNV-RP-C203 constants, "
            "the thickness exponent and the EN 1991-1-4 constants were entered from memory and <b>must be verified against the current editions before any number is reused</b>. Wind elevations in Phase B are measured from the mudline rather than from still-water level, "
            "which makes wind speeds at the tower top about 3 % high; this does not change the conclusions. The damping, soil and wave factors in the Monte Carlo are judgement.", N),
          P("<b>Verification.</b> checks.py reproduces the Phase B moments to 1e-13, the four Phase A frequencies, the critical wind speed, matches an independent rainflow implementation, and shows time-domain and spectral damage within %.0f %%. "
            "A latent normalisation issue in fem.modes() (rotation degrees of freedom left unscaled) changes the generalised masses by less than 1 tonne and does not affect Phase B; it is bypassed in modal.py." % (100 * max(abs(tot[s]["td|" + b] / tot[s]["dirlik|" + b] - 1) for s in S)), N)]

SimpleDocTemplate("technical_summary.pdf", pagesize=A4, leftMargin=1.8 * cm, rightMargin=1.8 * cm, topMargin=1.5 * cm, bottomMargin=1.7 * cm,
                  title="Fatigue Risk of Bare Offshore Monopiles During Installation", author="Riya Thripakkal Rajesh").build(story, onFirstPage=footer, onLaterPages=footer)
print("ok")
