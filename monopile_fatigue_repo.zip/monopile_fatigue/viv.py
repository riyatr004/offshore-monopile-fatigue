"""Simple VIV scenario model for the tower stages (screening, NOT a validated VIV prediction).
Exposure comes from the Phase B Weibull wind and Strouhal relation; the lock-in amplitude is an assumption
that is varied (damage vs amplitude) and, as one reference point, estimated with an EN 1991-1-4 Annex E
style formula (constants K, Kw, c_lat must be verified against the standard)."""
import numpy as np
import modal, fatigue as fat

ST, WIND_A, WIND_K, SHEAR, Z_HUB = 0.2, 11.0, 2.1, 0.11, 140.0
D_TOP, RHO_AIR, LOCK = 4.5, 1.225, 0.2          # tower top diameter, air density, lock-in half width


def weibull_cdf(U, z=Z_HUB):
    A = WIND_A * (z / Z_HUB) ** SHEAR
    return 1 - np.exp(-(U / A) ** WIND_K)


def amplitude_screening(mp, zeta, K=0.13, Kw=0.6, clat=0.2):
    """EN 1991-1-4 Annex E style: y/b = 1/St^2 * 1/Sc * K * Kw * c_lat  ->  top amplitude [m], Scruton number"""
    Sc = 2 * (2 * np.pi * zeta) * modal.tower_effective_mass(mp) / (RHO_AIR * D_TOP**2)
    return D_TOP / ST**2 / Sc * K * Kw * clat, Sc


def exposure_hours(f1, hours=4380.0):
    Uc = f1 * D_TOP / ST
    return Uc, (weibull_cdf((1 + LOCK) * Uc) - weibull_cdf((1 - LOCK) * Uc)) * hours


def viv_damage(f1, m_mud, Z_sec, t_mm, A_top, sn, eta=1.0, hours=4380.0, nbins=41, scf=1.0):
    """Miner damage of a lock-in scenario. Amplitude is triangular over the band (A_top at U=Uc, 0 at +-20 %),
    eta = fraction of the time inside the band with fully developed lock-in. Stress range = 2 A m_mud / Z."""
    Uc = f1 * D_TOP / ST
    edges = np.linspace((1 - LOCK) * Uc, (1 + LOCK) * Uc, nbins + 1)
    mid = 0.5 * (edges[1:] + edges[:-1])
    P = np.diff(weibull_cdf(edges))
    A = A_top * (1 - np.abs(mid / Uc - 1) / LOCK)
    dsig = scf * 2 * A * m_mud / Z_sec / 1e6
    n = f1 * 3600 * hours * P * eta
    return float(np.sum(n * sn.inv_N(dsig * sn.thick(t_mm))))
