"""Reproduces every figure, table and the PDF summary:  python run_all.py   (about 2 to 3 minutes)"""
import subprocess, sys, time
for script in ["phase_b_loading.py", "phase_c_fatigue.py", "phase_d_logger_mc.py", "checks.py", "make_summary.py"]:
    t = time.time(); print(">>", script, flush=True)
    subprocess.run([sys.executable, script], check=True, stdout=subprocess.DEVNULL if script != "checks.py" else None)
    print("   done in %.0f s" % (time.time() - t), flush=True)
