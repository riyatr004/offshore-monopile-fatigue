"""Phase D: logger specification and Monte Carlo uncertainty study.  All inputs illustrative."""
import json, numpy as np, pandas as pd
from scipy.stats import spearmanr
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import fem, modal, loads, fatigue as fat, viv
from modal import STAGES
from phase_c_fatigue import build_scatter, DFF, ZETA, HOURS

N_MC, SEED = 1500, 2026
g0 = 9.81
COL = ["tab:green", "tab:orange", "tab:purple", "tab:red"]


# ============================ 1. LOGGER REQUIREMENTS ============================
def logger_requirements():
    df = pd.read_csv("results_C_scatter.csv"); V = json.load(open("results_C.json"))["viv"]
    rows = []
    for s, st in enumerate(STAGES):
        d = df[df.stage == st].copy()
        d["D3"] = d["dirlik|" + fat.BASE]
        hs_sorted = d.groupby("Hs").D3.sum().sort_index(ascending=False)
        cum = hs_sorted.cumsum() / hs_sorted.sum()
        hs_min = float(cum.index[np.argmax(cum.values >= .99)])           # lowest Hs needed for 99 % of the damage
        rel = d[d.Hs >= hs_min - 1e-9]
        a_min, a_max = rel.a_top_ms2.min(), d.a_top_ms2.max()
        a_peak_wave = 3.9 * a_max                                         # Rayleigh 3 h maximum (about 1700 waves)
        a_viv = None
        if st in V:
            A_lim = np.interp(1 / DFF, np.array(V[st]["damage"][fat.BASE]), np.array(V[st]["A_over_D"])) * viv.D_TOP
            a_viv = A_lim * (2 * np.pi * V[st]["f1"]) ** 2
            a_viv_scr = V[st]["A_screen_m"] * (2 * np.pi * V[st]["f1"]) ** 2
        rows.append(dict(stage=st, Hs_min_99pct_damage=hs_min, a_rms_min_relevant_mg=a_min / g0 * 1e3, a_rms_max_mg=a_max / g0 * 1e3,
                         a_peak_wave_mg=a_peak_wave / g0 * 1e3, a_viv_Dlimit_mg=None if a_viv is None else a_viv / g0 * 1e3,
                         a_viv_screen_mg=None if a_viv is None else a_viv_scr / g0 * 1e3))
    rq = pd.DataFrame(rows)
    f2 = max(fem.modes(0, nh=fem.NH[k])[1][1] for k in fem.NH)               # mode 2 of the bare pile, stiff soil
    BW = 2.0
    noise = 0.1 * rq.a_rms_min_relevant_mg.min() / np.sqrt(BW) * 1e3          # ug/sqrt(Hz): noise = 10 % of smallest relevant signal
    spec = dict(range_g=1.0, noise_density_ug_rtHz=float(noise), f2_bare_stiff=float(f2),
                fs_raw_Hz=float(np.ceil(2.5 * f2 / 5) * 5), fs_stats_Hz=10.0, band_low_Hz=0.03, band_high_Hz=float(0.8 * 2.5 * f2 / 2.5))
    rq.to_csv("logger_signal_levels.csv", index=False)
    return rq, spec


# ============================ 2. LOGGING STRATEGIES ============================
def strategies(spec, p_storm=0.127, p_viv=0.303):
    """memory and energy for 6 months; all device numbers are ASSUMPTIONS (check data sheets)"""
    sec = HOURS * 3600
    P_SENS, P_ACT, P_SLP, E_B = 3e-3, 30e-3, 0.03e-3, 1e-6                  # W, W, W, J per byte written
    CH, BPS = 2, 3                                                          # 2 horizontal accelerometer channels, 24 bit
    fs_raw, fs_ev = spec["fs_raw_Hz"], spec["fs_raw_Hz"]
    raw_Bps = CH * BPS * fs_raw
    rows = []

    def add(name, mem_B, duty, wr_Bps, kept, lost):
        P = P_SENS + duty * P_ACT + (1 - duty) * P_SLP + wr_Bps * E_B
        E = P * sec / 3600
        rows.append(dict(strategy=name, memory_MB=mem_B / 1e6, avg_power_mW=P * 1e3, energy_Wh=E,
                         battery_cells=int(np.ceil(E / (0.5 * 19 * 3.6))), keeps=kept, loses=lost))

    add("Raw continuous (%g Hz, 2 ch)" % fs_raw, raw_Bps * sec, 0.10, raw_Bps, "everything: spectra, damping, VIV, cycles", "nothing, but memory and download")
    st_B = 120 * 6 * 24 * 365 / 2                                            # 120 B per 10 min record, 6 months
    add("10-min statistics + 32-band spectrum", st_B, 0.04, 120 / 600, "RMS, max, spectrum, dominant frequency", "cycle sequence; transient events")
    add("On-board rainflow histogram (stress range)", 4380 * 160 + st_B, 0.07, (160 / 3600) + 120 / 600, "damage directly; cycle counts per hour",
        "raw waveform; needs calibrated moment-to-acceleration transfer function")
    for lab, frac in (("storm trigger, bare pile", p_storm), ("lock-in trigger, tower stage", p_viv)):
        add("Event-triggered raw bursts + statistics (%s: %.0f %% of time)" % (lab, frac * 100), raw_Bps * sec * frac + st_B,
            0.04 + 0.10 * frac, raw_Bps * frac + 120 / 600, "full waveform where it matters + background statistics", "raw data outside trigger; trigger-threshold risk")
    return pd.DataFrame(rows)


# ============================ 3. MONTE CARLO ============================
def mc():
    rng = np.random.default_rng(SEED)
    sc = build_scatter()
    f = np.arange(int(.02 / 5e-4), int(1.8 / 5e-4) + 1) * 5e-4
    grid = loads.WaveGrid(f)
    S_all, Mdir, Fw = [], [], []
    wts = np.full(len(grid.zb), 1.0); wts[[0, -1]] = .5
    for _, r in sc.iterrows():
        S, F, _ = grid.tf(r.Hs, r.Tp); S_all.append(S); Mdir.append(grid.moment_tf(F)); Fw.append(F * wts[:, None])
    S_all, Mdir, Fw = np.array(S_all), np.array(Mdir), np.array(Fw)
    T_st = sc.hours.values * 3600
    # table of modal properties versus soil stiffness (interpolated in log nh)
    nh_tab = np.geomspace(3e6, 80e6, 16); lnt = np.log(nh_tab)
    tab = []
    for s in range(4):
        rec = dict(f1=[], Kn=[], m=[], Q=[], me=[])
        for nh in nh_tab:
            mp = modal.modal_props(s, nh=nh); m, sp = modal.moment_per_q(mp, 0.0)
            rec["f1"].append(mp["f1"]); rec["Kn"].append(mp["Kn"]); rec["m"].append(m)
            rec["Q"].append(np.einsum("z,szf->sf", mp["phi_w"], Fw)); rec["me"].append(modal.tower_effective_mass(mp) if s >= 2 else np.nan)
        tab.append({k: np.array(v) for k, v in rec.items()}); tab[-1]["Z"], tab[-1]["t"] = sp["Z"], sp["t"] * 1000
    # samples
    nh_s = np.clip(np.exp(rng.normal(np.log(15e6), .6, N_MC)), 3e6, 80e6)
    ze_s = np.clip(np.exp(rng.normal(np.log(.015), .4, N_MC)), .004, .04)
    hf_s = np.exp(rng.normal(0, .25, N_MC))
    vm_s = np.exp(rng.normal(0, .5, N_MC))                                    # VIV amplitude model factor
    et_s = rng.uniform(.25, 1, N_MC)                                          # fraction of band time with developed lock-in
    sn = fat.CURVES; base = fat.BASE
    out = {c: np.zeros((N_MC, 4)) for c in sn}; Dv = np.zeros((N_MC, 2)); Af = np.zeros((N_MC, 2)); f1s = np.zeros((N_MC, 4))
    for i in range(N_MC):
        ln = np.log(nh_s[i]); j = min(np.searchsorted(lnt, ln) - 1, len(lnt) - 2); w = (ln - lnt[j]) / (lnt[j + 1] - lnt[j])
        for s in range(4):
            T = tab[s]; ip = lambda a: (1 - w) * a[j] + w * a[j + 1]
            f1, Kn, m, Q = ip(T["f1"]), ip(T["Kn"]), ip(T["m"]), ip(T["Q"]); f1s[i, s] = f1
            Hh = (Mdir + m * (loads.sdof_H(f, f1, ze_s[i]) - 1)[None, :] * Q / Kn) / T["Z"] / 1e6
            G = np.abs(Hh) ** 2 * S_all
            for c, snc in sn.items():
                out[c][i, s] = fat.dirlik_damage(f, G, snc, T["t"], T_st, scale=hf_s[i]).sum()
            if s >= 2:
                Sc = 2 * 2 * np.pi * ze_s[i] * ip(T["me"]) / (viv.RHO_AIR * viv.D_TOP**2)
                A = viv.D_TOP / viv.ST**2 / Sc * .13 * .6 * .2 * vm_s[i]
                Dv[i, s - 2] = viv.viv_damage(f1, m, T["Z"], T["t"], A, sn[base], eta=et_s[i]); Af[i, s - 2] = A
    return dict(nh=nh_s, zeta=ze_s, hsf=hf_s, vm=vm_s, eta=et_s, wave=out, viv=Dv, A=Af, f1=f1s)


def pct(x):
    return dict(P5=float(np.percentile(x, 5)), P50=float(np.percentile(x, 50)), P95=float(np.percentile(x, 95)),
                P99=float(np.percentile(x, 99)), mean=float(np.mean(x)), P_exceed_1_over_DFF=float(np.mean(x > 1 / DFF)))


def mc_report(R):
    b = fat.BASE; res = {}
    for s, st in enumerate(STAGES):
        res[st] = dict(wave={c: pct(R["wave"][c][:, s]) for c in R["wave"]})
        if s >= 2: res[st]["viv_only"] = pct(R["viv"][:, s - 2]); res[st]["wave_plus_viv"] = pct(R["wave"][b][:, s] + R["viv"][:, s - 2])
    rho = {}
    for name, x in (("soil stiffness", R["nh"]), ("damping", R["zeta"]), ("wave height factor", R["hsf"])):
        rho[name] = float(spearmanr(x, np.log10(R["wave"][b][:, 0]))[0])
    rho_t = {}
    for name, x in (("soil stiffness", R["nh"]), ("damping", R["zeta"]), ("wave height factor", R["hsf"]), ("VIV amplitude factor", R["vm"]), ("lock-in occurrence", R["eta"])):
        rho_t[name] = float(spearmanr(x, np.log10(R["wave"][b][:, 2] + R["viv"][:, 0]))[0])
    res["spearman_bare_wave"], res["spearman_tower_wave_viv"] = rho, rho_t
    return res


def figures(R, res, spec):
    plt.rcParams.update({"font.size": 8, "axes.grid": True, "grid.alpha": .3}); b = fat.BASE
    fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
    for a, (x, lab, c, st) in zip(ax[:2], [(R["wave"][b][:, 0], "Bare monopile, waves only", COL[0], STAGES[0]),
                                           (R["wave"][b][:, 2] + R["viv"][:, 0], "+ Tower, waves + VIV scenario", COL[2], STAGES[2])]):
        a.hist(np.log10(x), bins=40, color=c, alpha=.8)
        for p, ls in ((5, ":"), (50, "-"), (95, "--")): a.axvline(np.log10(np.percentile(x, p)), color="k", ls=ls, lw=1, label="P%d = %.1e" % (p, np.percentile(x, p)))
        a.axvline(np.log10(1 / DFF), color="tab:red", lw=1.5, label="1/DFF = %.2f" % (1 / DFF))
        a.set_xlabel("log10 of 6-month damage [-]"); a.set_ylabel("samples"); a.set_title(lab); a.legend(fontsize=6.5)
    names = list(res["spearman_tower_wave_viv"]); v = [res["spearman_tower_wave_viv"][n] for n in names]
    ax[2].barh(names, v, color="tab:purple"); ax[2].set_xlabel("Spearman rank correlation with log damage"); ax[2].set_title("+ Tower: what drives the spread")
    fig.tight_layout(); fig.savefig("fig_mc.png", dpi=200); plt.close()

    # logger band figure: top-acceleration spectra vs noise floor
    f = np.arange(int(.02 * 10800), int(1.8 * 10800) + 1) / 10800; grid = loads.WaveGrid(f); fig, ax = plt.subplots(figsize=(6.5, 3.8))
    for (st, hs, tp, c, ls) in ((0, 1.5, 7, "tab:green", "-"), (0, 4, 8, "tab:green", "--"), (2, 4, 8, "tab:purple", "--")):
        S, F, _ = grid.tf(hs, tp); mp = modal.modal_props(st); X = loads.top_motion_tf(grid, F, mp, ZETA)
        ax.loglog(f, (2 * np.pi * f) ** 4 * np.abs(X) ** 2 * S / g0**2, c=c, ls=ls, label="%s, Hs %g m" % (STAGES[st], hs))
    ax.axhline((spec["noise_density_ug_rtHz"] * 1e-6) ** 2, color="k", ls=":", label="required noise floor (%.0f ug/rtHz)" % spec["noise_density_ug_rtHz"])
    ax.axvspan(.08, .17, color="tab:blue", alpha=.1); ax.set_xlim(.03, 2); ax.set_ylim(1e-14, 1e-4)
    ax.set_xlabel("frequency [Hz]"); ax.set_ylabel(r"top acceleration PSD [g$^2$/Hz]"); ax.set_title("What the logger must resolve"); ax.legend(fontsize=6.5)
    fig.tight_layout(); fig.savefig("fig_logger.png", dpi=200); plt.close()


def main():
    rq, spec = logger_requirements(); st = strategies(spec)
    pd.set_option("display.width", 250, "display.max_columns", 20, "display.max_colwidth", 60)
    print(rq.round(3).to_string()); print(json.dumps(spec, indent=1)); print(st.round(2).to_string())
    st.to_csv("logger_strategies.csv", index=False)
    R = mc(); res = mc_report(R)
    json.dump(dict(spec=spec, mc=res, n=N_MC), open("results_D.json", "w"), indent=1, default=float)
    figures(R, res, spec)
    b = fat.BASE
    print("\nMONTE CARLO (%d samples), baseline curve" % N_MC)
    for s in STAGES:
        w = res[s]["wave"][b]; print("  %-20s waves: P5 %.1e  P50 %.1e  P95 %.1e  P99 %.1e" % (s, w["P5"], w["P50"], w["P95"], w["P99"]))
        if "wave_plus_viv" in res[s]:
            v = res[s]["wave_plus_viv"]; print("  %-20s waves+VIV: P5 %.1e  P50 %.1e  P95 %.1e  P99 %.1e  P(D>1/DFF) = %.3f" % ("", v["P5"], v["P50"], v["P95"], v["P99"], v["P_exceed_1_over_DFF"]))
    print("  bare pile, curve sensitivity (P50):", {c: "%.1e" % res[STAGES[0]]["wave"][c]["P50"] for c in fat.CURVES})
    print("  Spearman bare:", {k: round(v, 2) for k, v in res["spearman_bare_wave"].items()})
    print("  Spearman tower:", {k: round(v, 2) for k, v in res["spearman_tower_wave_viv"].items()})


if __name__ == "__main__":
    main()
