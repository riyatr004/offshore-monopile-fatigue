"""Phase C: response, mudline stress, rainflow counting, Miner damage, 6-month waiting period.
Builds on fem.py (Phase A) and the Phase B load model (loads.py).  All inputs illustrative."""
import json, numpy as np, pandas as pd
from scipy.stats import norm
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import fem, modal, loads, fatigue as fat, viv
from modal import STAGES

T_SIM, DT, HOURS = 10800.0, 0.2, 4380.0          # 3 h realisations, 6 months = 4380 h
ZETA, SCF, DFF = 0.01, 1.0, 3.0                  # 1 % damping, nominal stress, design fatigue factor (illustrative)
LC = {"LC1": (1, 6), "LC2": (2, 6), "LC3": (2, 9), "LC4": (3, 8), "LC5": (4, 8), "LC6": (4, 12)}


def build_scatter(scale=1.9, shape=1.35, tp_sig=0.2):
    """Illustrative North Sea scatter table: Weibull Hs, lognormal Tp | Hs, steepness cut-off Hs/Lp <= 1/15."""
    edges = np.array([0, .75, 1.25, 1.75, 2.25, 2.75, 3.25, 3.75, 4.5, np.inf])
    cdf = lambda h: 1 - np.exp(-(h / scale) ** shape)
    hh = np.linspace(0, 15, 30001); pdf = shape / scale * (hh / scale) ** (shape - 1) * np.exp(-(hh / scale) ** shape)
    tp_edges, tp_lab = np.array([0, 6, 8, 10, 12, np.inf]), [5, 7, 9, 11, 13]
    rows = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        p_hs = cdf(hi) - cdf(lo)
        sel = (hh >= lo) & (hh < hi); hs = float(np.sum(hh[sel] * pdf[sel]) / np.sum(pdf[sel]))
        mu = np.log(4.5 + 1.35 * hs)
        with np.errstate(divide="ignore"):
            w = np.diff(norm.cdf((np.log(tp_edges) - mu) / tp_sig))
        w = np.where(hs / (1.56 * np.array(tp_lab, float) ** 2) <= 1 / 15, w, 0); w /= w.sum()
        rows += [dict(Hs=hs, Tp=tp, p=p_hs * wi) for tp, wi in zip(tp_lab, w) if wi > 0]
    df = pd.DataFrame(rows); df["p"] /= df["p"].sum(); df["hours"] = df["p"] * HOURS
    return df


def setup():
    f = np.arange(int(round(.02 * T_SIM)), int(round(1.8 * T_SIM)) + 1) / T_SIM
    grid = loads.WaveGrid(f)
    mps = [modal.modal_props(s) for s in range(4)]
    mm = [modal.moment_per_q(mp, 0.0) for mp in mps]
    return f, grid, mps, mm


def run_state(grid, mps, mm, Hs, Tp, seed, td=True):
    f = grid.f
    S, F, gam = grid.tf(Hs, Tp)
    out = []
    for s, (mp, (m_mud, sp)) in enumerate(zip(mps, mm)):
        H = loads.stress_tf(grid, F, mp, ZETA, m_mud, sp["Z"], SCF)
        G = np.abs(H) ** 2 * S
        t_mm = sp["t"] * 1000
        m0, m1, m2, m4 = fat.spectral_moments(f, G)
        row = dict(Hs=Hs, Tp=Tp, gamma=gam, stage=STAGES[s], sig_MPa=float(np.sqrt(m0)), nu0=float(np.sqrt(m2 / m0)))
        for cname, sn in fat.CURVES.items():
            row[f"dirlik|{cname}"] = float(fat.dirlik_damage(f, G, sn, t_mm, T_SIM)[0])
            row[f"narrow|{cname}"] = float(fat.dirlik_damage(f, G, sn, t_mm, T_SIM, method="narrow")[0])
        if td:
            x = loads.realise(f, S, H, T_SIM, DT, np.random.default_rng(seed * 10 + s))
            r, c = fat.rainflow(x)
            row["sig_td"] = float(x.std()); row["max_td"] = float(abs(x).max()); row["n_cycles"] = float(c.sum())
            for cname, sn in fat.CURVES.items():
                row[f"td|{cname}"] = fat.damage_ranges(r, c, sn, t_mm)
        Xtop = loads.top_motion_tf(grid, F, mp, ZETA)
        row["x_top_mm"] = float(np.sqrt(np.sum(np.abs(Xtop) ** 2 * S) * grid.df) * 1e3)
        row["a_top_ms2"] = float(np.sqrt(np.sum((2 * np.pi * f) ** 4 * np.abs(Xtop) ** 2 * S) * grid.df))
        out.append(row)
    return out


def main():
    f, grid, mps, mm = setup()
    sc = build_scatter()
    print("scatter table: %d states, mean Hs %.2f m, P(Hs>3)=%.3f, P(Hs>4)=%.3f" % (
        len(sc), np.sum(sc.Hs * sc.p), np.sum(sc.p[sc.Hs > 3]), np.sum(sc.p[sc.Hs > 4])))
    rows = []
    for i, r in sc.iterrows():
        for o in run_state(grid, mps, mm, r.Hs, r.Tp, seed=i + 1):
            o.update(hours=r.hours, p=r.p); rows.append(o)
    lc_rows = []
    for j, (n, (Hs, Tp)) in enumerate(LC.items()):
        for o in run_state(grid, mps, mm, Hs, Tp, seed=500 + j):
            o["case"] = n; lc_rows.append(o)
    df = pd.DataFrame(rows); dl = pd.DataFrame(lc_rows)
    df.to_csv("results_C_scatter.csv", index=False); dl.to_csv("results_C_LC.csv", index=False)

    # ---- 6-month totals
    base = fat.BASE
    tot = {}
    for stage in STAGES:
        d = df[df.stage == stage]
        tot[stage] = {meth + "|" + c: float(np.sum(d[meth + "|" + c] * d.hours / (T_SIM / 3600)))
                      for meth in ("td", "dirlik", "narrow") for c in fat.CURVES}
        tot[stage]["sigma_weighted_MPa"] = float(np.sqrt(np.sum(d.p * d.sig_MPa ** 2)))
    # ---- VIV scenario (tower stages)
    V = {}
    for s in (2, 3):                                  # bare pile / + TP: Uc too high (Phase B), no scenario
        mp = mps[s]; m_mud, sp = mm[s]
        Uc, h = viv.exposure_hours(mp["f1"])
        A_s, Sc = viv.amplitude_screening(mp, ZETA)
        m_tb, sp_tb = modal.moment_per_q(mp, fem.Z_TP_TOP)
        ratio = np.logspace(-3.3, -0.7, 60)
        curve = {c: [viv.viv_damage(mp["f1"], m_mud, sp["Z"], sp["t"] * 1000, a * viv.D_TOP, sn) for a in ratio] for c, sn in fat.CURVES.items()}
        V[STAGES[s]] = dict(f1=mp["f1"], Uc=Uc, hours_in_band=h, A_screen_m=A_s, Sc=Sc, A_over_D=ratio.tolist(), damage=curve,
                            D_screen={c: viv.viv_damage(mp["f1"], m_mud, sp["Z"], sp["t"] * 1000, A_s, sn) for c, sn in fat.CURVES.items()},
                            m_mud_MNm_per_m=m_mud / 1e6, Z=sp["Z"],
                            tower_base=dict(m=m_tb / 1e6, Z=sp_tb["Z"], t_mm=sp_tb["t"] * 1000,
                                D_screen=viv.viv_damage(mp["f1"], m_tb, sp_tb["Z"], sp_tb["t"] * 1000, A_s, fat.CURVES[base])))
    json.dump(dict(totals_6m=tot, viv=V, DFF=DFF), open("results_C.json", "w"), indent=1, default=float)

    # ---- checks and prints
    print("\n6-month wave damage, baseline curve (%s):" % base)
    for st in STAGES:
        t = tot[st]; print("  %-20s rainflow %.2e  Dirlik %.2e  narrow-band %.2e   (1/DFF = %.2f)" % (
            st, t["td|" + base], t["dirlik|" + base], t["narrow|" + base], 1 / DFF))
    print("\nCurve sensitivity (Dirlik, bare monopile):", {c: "%.1e" % tot[STAGES[0]]["dirlik|" + c] for c in fat.CURVES})
    lc5 = dl[dl.case == "LC5"]; print("\nLC5 hand check: M_rms/Z =", round(19.198e6 / mm[0][1]["Z"] / 1e6, 2), "MPa; spectral sigma by stage:", lc5.sig_MPa.round(2).tolist(),
                                     "time-domain std:", lc5.sig_td.round(2).tolist())
    print("\nVIV scenario (damage in 6 months, baseline curve) at screening amplitude / needed amplitude for D = 1/DFF:")
    for st, v in V.items():
        a = np.array(v["A_over_D"]); d = np.array(v["damage"][base]); idx = np.argmax(d >= 1 / DFF) if d.max() >= 1 / DFF else None
        print("  %-20s f1 %.2f Hz Uc %.1f m/s in-band %.0f h  screening A = %.3f m (Sc %.0f) D = %.2e   A/D for D=1/DFF: %s" % (
            st, v["f1"], v["Uc"], v["hours_in_band"], v["A_screen_m"], v["Sc"], v["D_screen"][base],
            "%.3f (A = %.2f m)" % (a[idx], a[idx] * viv.D_TOP) if idx is not None else ">0.2"))
    for st, v in V.items():
        print("  tower-base weld (z = 55 m) at screening amplitude, %s: m = %.0f MNm/m, Z = %.2f m3, D = %.2e" % (st, v["tower_base"]["m"], v["tower_base"]["Z"], v["tower_base"]["D_screen"]))
    return f, grid, mps, mm, df, dl, tot, V


# ============================ FIGURES ============================
COL = ["tab:green", "tab:orange", "tab:purple", "tab:red"]


def figures(f, grid, mps, mm, df, dl, tot, V):
    plt.rcParams.update({"font.size": 8, "axes.grid": True, "grid.alpha": .3})
    # ---- Fig 1: mode shapes per stage
    fig, ax = plt.subplots(1, 4, figsize=(10, 3.6), sharey=True)
    for s in range(4):
        z, fr, phi, *_ = fem.modes(s)
        for j, ls in enumerate(["-", "--", ":"]):
            ax[s].plot(phi[:, j], z, ls, color=COL[s], label="mode %d: %.2f Hz" % (j + 1, fr[j]))
        ax[s].axhspan(-30, 0, color="tab:brown", alpha=.12); ax[s].axhspan(0, 30, color="tab:blue", alpha=.08)
        ax[s].set_title(STAGES[s]); ax[s].legend(fontsize=6.5, loc="upper left"); ax[s].set_xlabel("normalised deflection [-]")
    ax[0].set_ylabel("height z [m]  (0 = mudline, 30 = MSL)")
    ax[0].text(-.95, -15, "soil", fontsize=7, color="tab:brown"); ax[0].text(-.95, 15, "water", fontsize=7, color="tab:blue")
    fig.tight_layout(); fig.savefig("fig_modes.png", dpi=200); plt.close()

    # ---- Fig 2: response (stress spectrum + time series), LC5
    S, F, _ = grid.tf(4, 8)
    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.6))
    ax[0].plot(f, S / S.max() * 1e-0 * 0 + np.nan)  # placeholder to keep axis order
    Hs_ = {}
    for s in range(4):
        H = loads.stress_tf(grid, F, mps[s], ZETA, mm[s][0], mm[s][1]["Z"], SCF); Hs_[s] = H
        ax[0].semilogy(f, np.abs(H) ** 2 * S, color=COL[s], label=STAGES[s])
        ax[0].axvline(mps[s]["f1"], color=COL[s], ls=":", lw=.8)
    ax[0].axvspan(.08, .17, color="tab:blue", alpha=.1)
    ax[0].set_xlim(0, 1.0); ax[0].set_ylim(1e-9, 3e3)
    ax[0].set_xlabel("frequency f [Hz]"); ax[0].set_ylabel(r"S$_\sigma$(f) [MPa$^2$/Hz]")
    ax[0].set_title("Mudline stress spectrum, LC5 (Hs 4 m, Tp 8 s)"); ax[0].legend(fontsize=7)
    ax[0].text(.2, 3e-8, "dotted: f$_1$ of each stage", fontsize=7)
    t = np.arange(int(T_SIM / DT)) * DT
    for s, lab in ((0, "bare monopile"), (3, "+ nacelle and rotor")):
        x = loads.realise(f, S, Hs_[s], T_SIM, DT, np.random.default_rng(7))
        ax[1].plot(t / 60, x, color=COL[s], lw=.7, label=lab)
    ax[1].set_xlim(0, 5); ax[1].set_xlabel("time [min]"); ax[1].set_ylabel("bending stress at mudline weld [MPa]")
    ax[1].set_title("Simulated stress history (same waves)"); ax[1].legend(fontsize=7)
    fig.tight_layout(); fig.savefig("fig_response.png", dpi=200); plt.close()

    # ---- Fig 3: damage vs sea state
    b = fat.BASE; fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.6))
    mk = {STAGES[0]: "o", STAGES[1]: "s", STAGES[2]: "^", STAGES[3]: "D"}
    for s, st in enumerate(STAGES):
        d = df[df.stage == st]
        sc_ = ax[0].scatter(d.Hs, d["dirlik|" + b] * 8, c=COL[s], marker=mk[st], s=16, alpha=.8, label=st)
    ax[0].set_yscale("log"); ax[0].set_xlabel("significant wave height Hs [m]"); ax[0].set_ylabel("damage per day [-]")
    ax[0].set_title("Damage per day for each sea state (Dirlik)"); ax[0].legend(fontsize=7)
    d0 = df[df.stage == STAGES[0]].copy(); d0["D6"] = d0["dirlik|" + b] * d0.hours / (T_SIM / 3600)
    g_ = d0.groupby("Hs").agg(D6=("D6", "sum"), hrs=("hours", "sum")).reset_index()
    ax[1].bar(range(len(g_)), g_.D6 / g_.D6.sum() * 100, color="tab:green")
    ax[1].set_xticks(range(len(g_))); ax[1].set_xticklabels(["%.1f" % h for h in g_.Hs], fontsize=7)
    ax[1].set_xlabel("Hs bin [m]"); ax[1].set_ylabel("share of 6-month damage [%]")
    ax[1].set_title("Bare monopile: which sea states cause the damage\n(6-month total D = %.1e)" % tot[STAGES[0]]["dirlik|" + b])
    ax2 = ax[1].twinx(); ax2.plot(range(len(g_)), g_.hrs / g_.hrs.sum() * 100, "k.-", lw=.8); ax2.set_ylabel("share of time [%]"); ax2.grid(False)
    fig.tight_layout(); fig.savefig("fig_damage.png", dpi=200); plt.close()

    # ---- Fig 4: VIV scenario
    fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.6))
    for k_, (st, v) in enumerate(V.items()):
        a = np.array(v["A_over_D"])
        ax[0].loglog(a, v["damage"][b], color=COL[2 + k_], label="%s (in band %.0f h)" % (st, v["hours_in_band"]))
        ax[0].plot(v["A_screen_m"] / viv.D_TOP, v["D_screen"][b], "o", color=COL[2 + k_], mfc="w")
    ax[0].axhline(1 / DFF, color="k", ls="--"); ax[0].text(.0006, 1 / DFF * 1.3, "D = 1/DFF (DFF = %g)" % DFF, fontsize=7)
    ax[0].set_xlabel("lock-in amplitude of tower top, A/D [-]"); ax[0].set_ylabel("6-month damage at mudline weld [-]")
    ax[0].set_title("VIV scenario: damage vs assumed amplitude"); ax[0].legend(fontsize=7)
    ax[0].text(.0006, 3e-9, "open circle: EN 1991-1-4 style screening amplitude", fontsize=6.5)
    names = ["Bare", "+ TP", "+ Tower", "+ RNA"]
    wave = [tot[s]["dirlik|" + b] for s in STAGES]
    ax[1].bar(np.arange(4) - .2, wave, .4, color="tab:blue", label="waves only")
    ax[1].bar([2.2, 3.2], [V[STAGES[2]]["D_screen"][b], V[STAGES[3]]["D_screen"][b]], .4, color="tab:orange", label="VIV screening amplitude")
    ax[1].set_yscale("log"); ax[1].axhline(1 / DFF, color="k", ls="--"); ax[1].set_xticks(range(4)); ax[1].set_xticklabels(names)
    ax[1].set_ylabel("6-month damage [-]"); ax[1].set_title("Waves vs VIV scenario (baseline S-N curve)"); ax[1].legend(fontsize=7)
    fig.tight_layout(); fig.savefig("fig_viv.png", dpi=200); plt.close()


if __name__ == "__main__":
    figures(*main())
